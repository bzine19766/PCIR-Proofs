# Table 4 — canonical-ordering ablation

Metric: popped DFS occurrences, including repeats, dead ends and pruned nodes.
All runs use `timeout=inf` (exhaustive). The noncanonical myciel4 count is computed by the memoised counter only; see notes below.

| Instance | Variant | Counter | Engine | Best χ | Match | Paper |
|---|---|---:|---:|---:|---|---:|
| myciel3.col | canonical | 2,325 | 2,325 | 4 | True | 2,325 |
| myciel3.col | noncanonical | 969,712 | 969,712 | 4 | True | 5,394 |
| myciel4.col | canonical | 929,315 | 929,315 | 5 | True | 929,315 |
| myciel4.col | noncanonical | 3,450,514,238,574,088 | (skipped) | 5 | n/a | 2,774,074 |

The canonical-ordering constraint reduces the popped-occurrence count of myciel3 from 969,712 to 2,325 (99.76%) and of myciel4 from 3,450,514,238,574,088 to 929,315 (nine orders of magnitude).

Notes:
- myciel3: both the notebook engine and the memoised counter reproduce 969,712 / 2,325. The paper's 5,394 figure for the noncanonical case was not reproduced by either method; its provenance is unresolved.
- myciel4: both methods reproduce 929,315 canonical. The noncanonical count of 3,450,514,238,574,088 is obtained by the memoised counter, because the direct engine cannot materialise that many states in memory. The two methods agree on every count that both can compute, which validates the counter for the larger case.

# Table 4 — myciel3.col canonical-ordering ablation

Graph: https://mat.tepper.cmu.edu/COLOR/instances/myciel3.col
Notebook Git blob: `8e1ba825363fddd146af4af601ba217a83e23510`
Metric: popped DFS occurrences, including repeats, dead ends and pruned nodes.

| Variant | Paper count | Independent count | Original-engine count | Best coloring | Engine agrees? | Matches paper? |
|---|---:|---:|---:|---:|---|---|
| canonical | 2,325 | 2,325 | 2,325 | 4 | True | True |
| noncanonical | 5,394 | 969,712 | 969,712 | 4 | True | False |

Canonical count is 2,325 (matches paper). Noncanonical count is 969,712 (paper value 5,394 not reproduced under this protocol).
The myciel4 row is not tested by this ablation.

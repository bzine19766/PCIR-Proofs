# Table 3 — DIMACS benchmark results

Per-instance timeout: 30.0 s.
Popped occurrences include repeated occurrences, dead ends and pruned nodes.
A target reached before timeout is not an exhaustive proof.

| Instance | |V| | |E| | Header edges | Target χ | Best found | Popped occurrences | Runtime (s) | Target reached | Exhaustive | Status |
|---|---:|---:|---|---:|---:|---:|---:|---|---|---|
| myciel3.col | 11 | 20 | 20 (undirected) | 4 | 4 | 2325 | 0.014 | True | True | TARGET_REACHED_EXHAUSTIVE |
| myciel4.col | 23 | 71 | 71 (undirected) | 5 | 5 | 929315 | 4.579 | True | True | TARGET_REACHED_EXHAUSTIVE |
| queen5_5.col | 25 | 160 | 320 (doubled) | 5 | 5 | 5687431 | 30.000 | True | False | TARGET_REACHED_TIMEOUT |
| le450_5a.col | 450 | 5714 | 5714 (undirected) | 5 | 13 | 2677773 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| le450_5b.col | 450 | 5734 | 5734 (undirected) | 5 | 13 | 2708939 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| myciel5.col | 47 | 236 | 236 (undirected) | 6 | 6 | 3323263 | 30.000 | True | False | TARGET_REACHED_TIMEOUT |
| queen6_6.col | 36 | 290 | 580 (doubled) | 7 | 9 | 7897781 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| queen7_7.col | 49 | 476 | 952 (doubled) | 7 | 10 | 7409620 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| le450_15a.col | 450 | 8168 | 8168 (undirected) | 15 | 21 | 4855939 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| le450_25a.col | 450 | 8260 | 8260 (undirected) | 25 | 27 | 4383536 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| myciel6.col | 95 | 755 | 755 (undirected) | 7 | 7 | 3220060 | 30.000 | True | False | TARGET_REACHED_TIMEOUT |
| myciel7.col | 191 | 2360 | 2360 (undirected) | 8 | 8 | 3347296 | 30.000 | True | False | TARGET_REACHED_TIMEOUT |
| queen8_8.col | 64 | 728 | 1456 (doubled) | 9 | 12 | 7176770 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
| queen9_9.col | 81 | 1056 | 2112 (doubled) | 10 | 15 | 8012226 | 30.000 | False | False | TIMEOUT_TARGET_NOT_REACHED |
